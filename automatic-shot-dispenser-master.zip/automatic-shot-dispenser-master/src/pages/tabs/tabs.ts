import { Component } from '@angular/core';
import { Http } from '@angular/http';


@Component({
  templateUrl: 'tabs.html'
})
export class TabPage {

  IPAddress: string = "";
  Connected: boolean = false;
  BaseUrl = "http://";
  On: boolean = true;
  constructor(private http: Http) {

  }

  OnMe() {
    var self = this;
    self.http.get(self.BaseUrl + self.IPAddress + "/mode/1").subscribe(m => {
      if (m.status == 200) {
        self.On = true;
      }
      else {
        self.On = false;
      }
    });
  }
  OffMe() {
    var self = this;
    self.http.get(self.BaseUrl + self.IPAddress + "/mode/0").subscribe(m => {

      if (m.status == 200) {
        self.On = false;
      }
      else {
        self.On = true;
      }
    });
  }
  Connect() {
    var self = this;
    self.http.get(self.BaseUrl + self.IPAddress).subscribe(m => {
      if (m.status == 200) {
        self.Connected = true;
      }
      else {
        self.Connected = false;
      }
    });
  }
  Clear() {
    this.IPAddress = "";
    this.Connected = false;
  }
}
